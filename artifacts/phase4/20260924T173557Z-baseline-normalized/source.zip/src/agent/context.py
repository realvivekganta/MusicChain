"""Shared input definitions and validation for the agent and database.

CustomerContext comes from the trusted caller (simulated in Studio), separately
from chat. Query models hold business filters and never include customer identity.
"""

# --- Imports -----------------------------------------------------------------

from dataclasses import dataclass
from typing import Annotated

from pydantic import BaseModel, ConfigDict, Field, StringConstraints

# --- Trusted runtime context: immutable for an invocation ---------------------


@dataclass(frozen=True)
class CustomerContext:
    customer_id: int

    def __post_init__(self) -> None:
        # bool is an int subclass; do not silently accept it as an identity.
        if type(self.customer_id) is not int or self.customer_id <= 0:
            raise ValueError("customer_id must be a positive integer from the trusted caller")


def require_customer(context: CustomerContext | None) -> CustomerContext:
    """Fail closed even when invoked outside normal schema validation."""
    if not isinstance(context, CustomerContext):
        raise ValueError("Trusted CustomerContext is required; identity cannot come from chat")
    context.__post_init__()
    return context


# --- Model-selected filters: reusable field constraints -----------------------

PositiveId = Annotated[int, Field(strict=True, gt=0, le=2**63 - 1)]
SearchText = Annotated[str, StringConstraints(strip_whitespace=True, min_length=1, max_length=100)]
PageSize = Annotated[int, Field(strict=True, ge=1, le=50)]
PageOffset = Annotated[int, Field(strict=True, ge=0, le=10_000)]
RecommendationCount = Annotated[int, Field(strict=True, ge=1, le=10)]
SupportReason = Annotated[
    str, StringConstraints(strip_whitespace=True, min_length=1, max_length=1000)
]


# --- Validated purchase filters ----------------------------------------------


class PurchaseQuery(BaseModel):
    """Model-selectable business filters. Identity comes from CustomerContext."""

    model_config = ConfigDict(extra="forbid")
    invoice_id: PositiveId | None = None
    search: SearchText | None = None
    limit: PageSize = 20
    offset: PageOffset = 0


# --- Music discovery: catalog filters and recommendation preferences ----------


class CatalogQuery(BaseModel):
    """Literal catalog search and optional exact, case-insensitive genre."""

    model_config = ConfigDict(extra="forbid")
    search: SearchText | None = None
    genre: SearchText | None = None
    limit: PageSize = 20
    offset: PageOffset = 0


class RecommendationQuery(BaseModel):
    """Preferences narrow results; ownership exclusion cannot be disabled."""

    model_config = ConfigDict(extra="forbid")
    genre: SearchText | None = None
    limit: RecommendationCount = 3


# --- Support action: reviewed business arguments, never approval or identity ---


class SupportRequestInput(BaseModel):
    """Validate the final invoice and reason after any reviewer edits."""

    model_config = ConfigDict(extra="forbid")
    invoice_id: PositiveId
    reason: SupportReason
